//
//  ViewController.swift
//  demo
//
//  Created by user224381 on 6/14/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    
    var audioBookArr = [AudioBookModel]()
    var audioBookAPIParserInstance = AudioBookAPIParser()
    @IBOutlet weak var AlbumTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        AlbumTableView.delegate = self
        AlbumTableView.dataSource = self
        AlbumTableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        
        audioBookAPIParserInstance.fetchAPI{ audioArray in
            self.audioBookArr = audioArray
        }
        AlbumTableView.reloadData()
       
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return audioBookArr.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as? TableViewCell{
            
            cell.artistCellName.text = audioBookArr[indexPath.row].artistName ?? ""
            let id = audioBookArr[indexPath.row].artistId ?? 0
            cell.artistCellId.text = String(id)
            cell.artistCellImage.loadFrom(URLAddress: audioBookArr[indexPath.row].artistViewUrl ?? "")
            return cell
        }
    
        return UITableViewCell()
        
    }

}


