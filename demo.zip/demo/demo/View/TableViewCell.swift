//
//  TableViewCell.swift
//  demo
//
//  Created by user224381 on 6/14/23.
//

import UIKit

class TableViewCell: UITableViewCell {

   
    @IBOutlet weak var artistCellName: UILabel!
    @IBOutlet weak var artistCellId: UILabel!
    @IBOutlet weak var artistCellImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        
        
    }
    
}
