//
//  AudioBook.swift
//  demo
//
//  Created by user224381 on 6/14/23.
//

import Foundation

struct ResponseDataModel : Codable{
    let resultCount : Int
    let results : [AudioBookModel]
}

struct AudioBookModel : Codable {
    let artistId : Int?
    let artistName : String?
    let artistViewUrl : String?
    let country : String?
}
