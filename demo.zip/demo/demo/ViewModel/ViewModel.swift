//
//  ViewModel.swift
//  demo
//
//  Created by user224381 on 6/14/23.
//

import Foundation
import UIKit

class AudioBookAPIParser{
    
    static let fetchService = AudioBookAPIParser()
    var audioBookList = [AudioBookModel]()
    
    func fetchAPI(completionHandler : @escaping ([AudioBookModel])->Void){
        print("fetchapi called")
        let url = "https://itunes.apple.com/search?term=adele"
        let urlString = URL(string: url)
        URLSession.shared.dataTask(with: urlString!) { (data, resp, error) in
            guard let data = data else{
                print("Cannot FETCH API")
                return
            }
            do{
                let decodedData = try JSONDecoder().decode(ResponseDataModel.self, from: data)
                //self.AudioBookList = decodedData.results
                //print(self.AudioBookList)
                //print(self.AudioBookList.count
                self.audioBookList = decodedData.results
                completionHandler(self.audioBookList)
            }catch{
                print("Error decoding data", error ?? "")
            }
        }.resume()
        
    }
    
    
}

extension UIImageView {
    func loadFrom(URLAddress: String) {
        guard let url = URL(string: URLAddress) else {
            return
        }
        
        DispatchQueue.main.async { [weak self] in
            if let imageData = try? Data(contentsOf: url) {
                if let loadedImage = UIImage(data: imageData) {
                        self?.image = loadedImage
                }
            }
        }
    }
}
